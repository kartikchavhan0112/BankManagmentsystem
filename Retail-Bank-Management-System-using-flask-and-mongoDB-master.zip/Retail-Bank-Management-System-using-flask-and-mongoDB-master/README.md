# Retail-Bank-Management-System-using-flask-and-mongoDB
#mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=false
This is the complete project on banking management

#Customer
1. you can create a customer
2. You can create account for customer for any type i.e; savings,current
3.customer can add money to their account
4. customer can withraw and transfer money from their account
5. customer can check the account summary

#Bank Staff
1. staff can check the status of all the customers or of a particular customer
2. they can update the account details of the customer
3. they can delete the customer account
4. they can check the activity of all the customers
5. can provide the account statement to customer


#Form
all the form are designed using the Flaskform 


to run this project u need to run these commands
1. pip install -r requirements.txt
2. flask run

